<div class="container">
    <?= form_open_multipart('ibu/tambah');?>
        <legend>Tambah Data Ibu</legend>
        <div class="mb-3">
            <label for="nama_ibu" class="form-label">nama Ibu</label>
            <input type="text" class="form-control" id="nama_ibu" name="nama_ibu" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('nama_ibu'); ?></div>
        </div>
        <div class="mb-3">
            <label for="nama_anak" class="form-label">nama_anak</label>
            <input type="text" class="form-control" id="nama_anak" name="nama_anak" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('nama_anak'); ?></div>
        </div> 
        </div>
        <input type="submit" value="submit" class="btn btn-primary"></input>
    </form>
</div>

