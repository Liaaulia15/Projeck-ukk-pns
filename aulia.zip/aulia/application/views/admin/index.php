<div class="container">
      <h1>Welcome </h1>
</div>
<style>
body
{
      background-color: bisque;
}
</style>