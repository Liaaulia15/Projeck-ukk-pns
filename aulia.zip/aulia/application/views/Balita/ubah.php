<div class="container">
    <?= form_open_multipart('balita/tambah');?>
        <legend>Ubah Data Balita</legend>
        <div class="mb-3">
            <label for="nama" class="form-label">nama</label>
            <input type="text" class="form-control" id="nama" name="nama" style="width : 500px;" value="<?= $balita['nama']; ?>">
            <div class="form-text text-danger"><?= form_error('nama'); ?></div>
        </div>
        <div class="mb-3">
             <label for="jenis_kelamin" class="form-label">jenis kelamin</label>
            <input type="text" class="form-control" id="jenis_kelamin" name="jenis_kelamin" style="width : 500px;" value="<?= $balita['jenis_kelamin']; ?>">
            <div class="form-text text-danger"><?= form_error('jenis_kelamin'); ?></div>
        </div>
        <div class="mb-3">
            <label for="umur" class="form-label">umur</label>
            <input type="text" class="form-control" id="umur" name="umur" style="width : 500px;" value="<?= $balita['umur']; ?>">
            <div class="form-text text-danger"><?= form_error('umur'); ?></div>
        </div> 
        </div>
        <input type="submit" value="submit" class="btn btn-primary"></input>
    </form>
</div>








































