<div class="container">
    <?= form_open_multipart('balita/tambah');?>
        <legend>Tambah Data Balita</legend>
        <div class="mb-3">
            <label for="nama" class="form-label">nama</label>
            <input type="text" class="form-control" id="nama" name="nama" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('nama'); ?></div>
        </div>
        <div class="mb-3">
            <label for="jenis kelamin" class="form-label">jenis kelamin</label>
            <input type="text" class="form-control" id="jenis kelamin" name="jenis kelamin" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('jenis kelamin'); ?></div>
        </div> 
        <div class="mb-3">
            <label for="umur" class="form-label">umur</label>
            <input type="text" class="form-control" id="umur" name="umur" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('umur'); ?></div>
        </div> 
        </div>
        <input type="submit" value="submit" class="btn btn-primary"></input>
    </form>
</div>





  























































