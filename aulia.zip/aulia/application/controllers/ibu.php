<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ibu extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
        $this->load->model('Model_ibu');
        if(!$this->session->userdata('username')) {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] = 'ibu';

        $data['ibu'] = $this->Model_ibu->getAllibu();
        if( $this->input->post('keyword') ) {
            $data['ibu'] = $this->Model_ibu->Cariibu();
        }
        $this->load->view('templates/header.php', $data);
        $this->load->view('ibu/index.php', $data);
        $this->load->view('templates/footer.php');
    }
    public function tambah()
    {
        $this->form_validation->set_rules('nama_ibu', 'nama_ibu', 'trim|required');
        $this->form_validation->set_rules('nama_anak', 'nama_anak', 'trim|required');

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Tambah ibu';

            $this->load->view('templates/header.php', $data);
            $this->load->view('ibu/tambah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_ibu->Tambahibu();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('ibu');
        }
        
    }
      public function ubah($id)
{
    $this->form_validation->set_rules('nama_ibu', 'nama_ibu', 'trim|required');
    $this->form_validation->set_rules('nama_anak', 'nama_anak', 'trim|required');
    

    $data['ibu'] = $this->Model_ibu->getibuById($id);

    if($this->form_validation->run() == false ) {
        $data['title'] = 'Ubah ibu';

        $this->load->view('templates/header.php', $data);
        $this->load->view('ibu/ubah.php', $data);
        $this->load->view('templates/footer.php');
    } else {
        $this->Model_ibu->Ubahibu();
        $this->session->set_flashdata('flash', 'Diubah');
        redirect('ibu');
    }
} 
    public function hapus($id)
    {
        $this->Model_ibu->hapusibu($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('ibu');
    }
}


