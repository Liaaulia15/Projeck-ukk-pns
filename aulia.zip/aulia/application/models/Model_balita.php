<?php
class Model_balita extends CI_model 
{
    public function getAllbalita()
    {
        return $query = $this->db->get('balita')->result_array();
    }

    public function Tambahbalita()
    {
        $this->load->library('upload', true);
        $data = [
            "nama" => $this->input->post('nama', true),
            "jenis_kelamin" => $this->input->post('jenis_kelamin', true),
            "umur" => $this->input->post('umur', true),   
        ];

        $this->db->insert('balita', $data);

        $this->session->set_flashdata('flash', 'ditambahkan');
    }

    public function Ubahbalita()
    {
        $data = [
            "nama" => $this->input->post('nama', true),
            "jenis_kelamin" => $this->input->post('jenis_kelamin', true),
            "umur" => $this->input->post('umur', true),
            
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('balita', $data);
    }

    public function hapusbalita($id)       
    {
        $this->db->where('id', $id);
        $this->db->delete('balita');
    }
    public function getbalitaById($id)
    {
        return $this->db->get_where('balita', ['id' => $id])->row_array();
    }
  
	public function Caribalita()
	{
       $keyword = $this->input->post('keyword', true);
       $this->db->like('nama',$keyword);
       return $this->db->get('balita')->result_array();
	}
 }
?>
