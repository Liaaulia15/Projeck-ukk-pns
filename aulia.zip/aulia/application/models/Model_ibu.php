<?php
class Model_ibu extends CI_model 
{
    public function getAllibu()
    {
        return $query = $this->db->get('ibu')->result_array();
    }

    public function Tambahibu()
    {
        $this->load->library('upload', true);
        $data = [
            "nama_ibu" => $this->input->post('nama_ibu', true),
            "nama_anak" => $this->input->post('nama_anak', true),
            
        ];

        $this->db->insert('ibu', $data);

        $this->session->set_flashdata('flash', 'ditambahkan');
    }

     public function Ubahibu()
{
    $data = [
        "nama_ibu" => $this->input->post('nama_ibu', true),
        "nama_anak" => $this->input->post('nama_anak', true),
    ];

    $this->db->where('id', $this->input->post('id'));
    $this->db->update('ibu', $data);
}

public function hapusibu($id)       
{
    $this->db->where('id', $id);
    $this->db->delete('ibu');
}
public function getibuById($id)
{
    return $this->db->get_where('ibu', ['id' => $id])->row_array();
}

public function Cariibu()
{
   $keyword = $this->input->post('keyword', true);
   $this->db->like('nama_ibu',$keyword);
   return $this->db->get('ibu')->result_array();
}
}

?>
